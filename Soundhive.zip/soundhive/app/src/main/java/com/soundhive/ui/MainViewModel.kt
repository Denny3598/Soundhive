package com.soundhive.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.soundhive.auth.AuthStore
import com.soundhive.data.AppUpdateChecker
import com.soundhive.data.LocalMediaRepository
import com.soundhive.data.YtMusicRepository
import com.soundhive.data.lyrics.EmbeddedLyrics
import com.soundhive.data.lyrics.LyricLine
import com.soundhive.data.lyrics.LyricsRepository
import com.soundhive.data.lyrics.LyricsSource
import com.soundhive.data.settings.AppSettings
import com.soundhive.data.innertube.Innertube
import com.soundhive.data.innertube.PlaybackTracker
import com.soundhive.data.innertube.StreamResolver
import com.soundhive.data.model.Account
import com.soundhive.data.model.BrowseType
import com.soundhive.data.model.DetailPage
import com.soundhive.data.model.HomeShelf
import com.soundhive.data.model.LibraryPage
import com.soundhive.data.model.LibraryState
import com.soundhive.data.model.LikeStatus
import com.soundhive.data.model.PlaylistPrivacy
import com.soundhive.data.model.SearchFilter
import com.soundhive.data.model.SearchResult
import com.soundhive.data.model.Song
import com.soundhive.data.model.SongMenu
import com.soundhive.data.model.UiState
import com.soundhive.data.model.UserPlaylist
import com.soundhive.data.settings.SearchHistory
import com.soundhive.download.Downloads
import android.util.LruCache
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.soundhive.data.sources.SourceKind
import com.soundhive.data.sources.SourceRegistry
import java.util.concurrent.atomic.AtomicLong

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val authStore = AuthStore(app)

    private val _signedIn = MutableStateFlow(authStore.isSignedIn)
    val signedIn: StateFlow<Boolean> = _signedIn.asStateFlow()

    private val _home = MutableStateFlow<UiState<List<HomeShelf>>>(UiState.Loading)
    val home: StateFlow<UiState<List<HomeShelf>>> = _home.asStateFlow()

    /**
     * Token for the next page of Home shelves; null once there's nothing
     * more. Declared here rather than by [loadMoreHome] because [init] calls
     * [loadHome] synchronously up to its first suspension point — a property
     * declared after [init] would still be null when that runs.
     */
    private var homeContinuation: String? = null

    /** Titles already on screen, so a later page can't repeat a shelf. */
    private val homeSeenTitles = mutableSetOf<String>()

    private val _homeLoadingMore = MutableStateFlow(false)
    val homeLoadingMore: StateFlow<Boolean> = _homeLoadingMore.asStateFlow()

    private val _explore = MutableStateFlow<UiState<List<HomeShelf>>>(UiState.Loading)
    val explore: StateFlow<UiState<List<HomeShelf>>> = _explore.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _results = MutableStateFlow<UiState<List<SearchResult>>?>(null)
    val results: StateFlow<UiState<List<SearchResult>>?> = _results.asStateFlow()

    /** Songs is the default tab; there is no "All" tab any more. */
    private val _filter = MutableStateFlow(SearchFilter.SONGS)
    val filter: StateFlow<SearchFilter> = _filter.asStateFlow()

    /**
     * What the search page offers while a query is being typed, led by the
     * query itself.
     *
     * Non-empty *is* the signal that the field is mid-edit, so the screen
     * needs no second flag: these rows are shown in place of the results
     * whenever there are any, and cleared the moment a search is actually run
     * — see [submitSearch], [searchFor].
     *
     * Element 0 is always the raw text as typed. It's put there by the
     * keystroke itself rather than taken from the response, so the row the
     * thumb is already heading for is correct before the network answers, and
     * stays correct if it never does — YouTube's list never contains the
     * half-typed text, only completions of it.
     */
    private val _suggestions = MutableStateFlow<List<String>>(emptyList())
    val suggestions: StateFlow<List<String>> = _suggestions.asStateFlow()

    // The search pipeline's own state. Declared here, above [init], because
    // that is where the collector is started from and a property declared
    // below it would still be null when it runs. See [startSearchPipeline].

    /**
     * Buffered so an emission is never lost to a collector that happens to be
     * mid-search, and [BufferOverflow.DROP_OLDEST] because when two arrive
     * together the later one is the one meant.
     */
    private val searchRequests = MutableSharedFlow<SearchRequest>(
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    /**
     * The same arrangement as [searchRequests], for the typeahead — where the
     * drop policy earns its keep rather than just being safe: this one really
     * does take a keystroke each, and a fast typist's backlog should collapse
     * to the prefix they ended on instead of being worked through a letter at
     * a time.
     */
    private val suggestRequests = MutableSharedFlow<String>(
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    private val newestRequestId = AtomicLong(0L)

    /**
     * Results of recent searches, so a query searched before is answered
     * without asking again. That covers the two ways a query is repeated most:
     * a filter tab, which re-runs the same text against a different tab and
     * then usually goes back, and a term tapped out of the recent searches.
     *
     * Its other half is [prefixMatch], which is what the typeahead makes worth
     * keeping: picking "coldplay yellow" off a list is normally preceded by
     * having searched "coldplay", and those results are close enough to leave
     * up for the moment the narrower one takes rather than blanking the page
     * to a spinner.
     */
    private val searchCache = LruCache<String, List<SearchResult>>(SEARCH_CACHE_ENTRIES)

    /** Synced lyrics for whatever is playing; null while unknown or absent. */
    private val _lyrics = MutableStateFlow<List<LyricLine>?>(null)
    val lyrics: StateFlow<List<LyricLine>?> = _lyrics.asStateFlow()

    /** Which of the four databases [lyrics] came from, for the panel's credit. */
    private val _lyricsSource = MutableStateFlow<LyricsSource?>(null)
    val lyricsSource: StateFlow<LyricsSource?> = _lyricsSource.asStateFlow()

    /**
     * Whether the lookup for the current track has finished. [lyrics] alone
     * can't tell "still looking" apart from "looked, found nothing" — both
     * are null — and the player needs that distinction to show "Lyrics not
     * available" only once it actually means that.
     */
    private val _lyricsChecked = MutableStateFlow(false)
    val lyricsChecked: StateFlow<Boolean> = _lyricsChecked.asStateFlow()

    private var lyricsJob: Job? = null

    private data class LyricsKey(
        val videoId: String,
        val sources: Set<LyricsSource>,
        val order: List<LyricsSource>,
        val prioritizeSyllableSync: Boolean,
    )

    /**
     * What the loaded lyrics are for. Both the track *and* the settings that
     * chose them, so switching a source on or off, reordering sources, or
     * toggling syllable priority re-runs the lookup.
     */
    private var lyricsFor: LyricsKey? = null

    /**
     * Called as the playing track changes; cheap no-op when already loaded.
     *
     * [localUri] is the audio file on disk when this track was downloaded.
     * Consulted before any network call: what is already inside the file
     * is the fastest, cheapest answer there is, and it is what keeps a
     * downloaded song show nothing offline.
     */
    fun loadLyrics(
        videoId: String,
        title: String,
        artist: String,
        durationMs: Long,
        album: String? = null,
        localUri: String? = null,
    ) {
        val sources = if (AppSettings.syncedLyrics.value) {
            AppSettings.lyricsSources.value
        } else {
            emptySet()
        }
        val order = AppSettings.lyricsSourceOrder.value
        val prioritizeSyllable = AppSettings.prioritizeSyllableSync.value
        val key = LyricsKey(videoId, sources, order, prioritizeSyllable)
        if (lyricsFor == key) return
        lyricsFor = key
        _lyrics.value = null
        _lyricsSource.value = null
        lyricsJob?.cancel()
        if (sources.isEmpty()) {
            // Switched off, or every source unticked. Nothing to look up, and
            // nothing to say about it — the player drops the lyric strip
            // rather than reporting a track with no lyrics.
            _lyricsChecked.value = true
            return
        }
        _lyricsChecked.value = false
        lyricsJob = viewModelScope.launch {
            // The file first, and without the duration gate below: a length is
            // only needed to *match* a track against a stranger's database, and
            // nothing is being matched here — these lyrics were written into
            // this exact file, for this exact recording.
            if (localUri != null) {
                EmbeddedLyrics.forUri(getApplication(), localUri)?.let { embedded ->
                    _lyrics.value = embedded
                    // No source to name: what the file records is the lyrics,
                    // not which of the services they came from months ago.
                    _lyricsSource.value = null
                    _lyricsChecked.value = true
                    return@launch
                }
            }
            if (durationMs <= 0L) {
                // Duration arrives a beat after the track does; wait for it.
                lyricsFor = null
                return@launch
            }
            val found = LyricsRepository.lyrics(
                videoId = videoId,
                title = title,
                artist = artist,
                durationMs = durationMs,
                album = album,
                sources = sources,
                order = order,
                prioritizeSyllableSync = prioritizeSyllable,
            )
            _lyrics.value = found?.lines
            _lyricsSource.value = found?.source
            _lyricsChecked.value = true
        }
    }

    private val _account = MutableStateFlow<Account?>(null)
    val account: StateFlow<Account?> = _account.asStateFlow()

    private val _library = MutableStateFlow<UiState<LibraryPage>>(UiState.Loading)
    val library: StateFlow<UiState<LibraryPage>> = _library.asStateFlow()

    /**
     * Album / artist / playlist pages, as a stack — opening an artist from an
     * album page and pressing back returns to the album, not to search.
     */
    private val _detailStack = MutableStateFlow<List<DetailPage>>(emptyList())
    val detailStack: StateFlow<List<DetailPage>> = _detailStack.asStateFlow()


    /** Set once per launch if GitHub has a release newer than this build. */
    val updateAvailable: StateFlow<AppUpdateChecker.UpdateInfo?> = AppUpdateChecker.available

    // ---- Ratings, library and playlists -------------------------------------

    /**
     * Ratings this session has set, which win over whatever the library feed
     * last said.
     *
     * Kept apart from the library rather than folded into it because the two
     * answer different questions: Liked Music is what YouTube knew when the
     * page was fetched, and this is what the user has done since. Layering
     * them ([likeStatuses]) means a tap shows immediately without the library
     * having to be re-fetched, and a later refresh can't undo it.
     */
    private val _likeOverrides = MutableStateFlow<Map<String, LikeStatus>>(emptyMap())

    /** Every rating known for this account: the library's, then this session's. */
    val likeStatuses: StateFlow<Map<String, LikeStatus>> =
        combine(_library, _likeOverrides) { library, overrides ->
            val liked = (library as? UiState.Success)?.data?.likedSongs
                ?.associate { it.videoId to LikeStatus.LIKE }
                .orEmpty()
            liked + overrides
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    fun likeStatusOf(videoId: String): LikeStatus =
        likeStatuses.value[videoId] ?: LikeStatus.INDIFFERENT

    /**
     * Sets (or clears) the thumbs rating on [videoId].
     *
     * Written to the screen first and rolled back if YouTube refuses. A rating
     * is a one-tap, low-stakes action taken while a song is playing; waiting
     * on a round trip before the heart fills reads as the tap not having
     * registered, and people tap again.
     */
    fun setLike(videoId: String, status: LikeStatus) {
        if (!requireSignIn()) return
        val previous = likeStatusOf(videoId)
        if (previous == status) return
        _likeOverrides.value += (videoId to status)
        viewModelScope.launch {
            YtMusicRepository.rate(videoId, status).fold(
                onSuccess = {
                    // Liked Music is now out of date either way.
                    libraryStale = true
                    if (status != LikeStatus.LIKE) dropFromLikedLists(videoId)
                    // Clearing the heart means forgetting the song, not
                    // demoting it — see [forgetFromLibrary].
                    val unliked = previous == LikeStatus.LIKE &&
                        status == LikeStatus.INDIFFERENT
                    if (unliked) forgetFromLibrary(videoId)
                },
                onFailure = {
                    _likeOverrides.value += (videoId to previous)
                },
            )
        }
    }

    /**
     * Takes an un-liked track out of the library as well, and reports whether
     * it did.
     *
     * Liking and saving are two independent flags on YouTube's side, and
     * clearing only the first leaves the song saved — still feeding the
     * Library tab's Artists shelf, still in the library feeds, with nowhere
     * left in this app to reach it and finish the job. Clearing the heart
     * reads as "forget this song", so it clears both.
     *
     * The token is fetched here rather than taken from [songMenu] because the
     * heart in the player never opens a menu, so there is often nothing
     * cached to take. One extra request, on an action nobody performs in bulk.
     * A song that was never saved has no removal token and this is a no-op.
     */
    private suspend fun forgetFromLibrary(videoId: String): Boolean {
        val menu = YtMusicRepository.songMenu(videoId).getOrNull() ?: return false
        val token = menu.removeFromLibraryToken?.takeIf { menu.inLibrary } ?: return false
        if (YtMusicRepository.setLibraryStatus(token).isFailure) return false
        // The menu may be the one on screen; don't leave it offering a
        // removal that has already happened.
        _songMenu.value = _songMenu.value?.copy(inLibrary = false)
        return true
    }

    /**
     * Takes an un-liked track out of the lists that exist *because* it was
     * liked — the Library tab's Liked Music section, and the Liked Music page
     * itself if it happens to be open.
     *
     * Marking the library stale isn't enough on its own: that only acts when
     * the tab is next opened, and un-liking is nearly always done from inside
     * one of these two lists, looking straight at the row. Leaving it there
     * reads as the tap not having worked — the menu says "Like" again while
     * the song sits in Liked Music.
     *
     * Only ever removes. A track liked from somewhere else doesn't get spliced
     * into a list that YouTube orders for itself; the next fetch places it.
     */
    private fun dropFromLikedLists(videoId: String) {
        val library = (_library.value as? UiState.Success)?.data
        if (library != null && library.likedSongs.any { it.videoId == videoId }) {
            _library.value = UiState.Success(
                library.copy(likedSongs = library.likedSongs.filterNot { it.videoId == videoId }),
            )
        }
        _detailStack.value = _detailStack.value.map { page ->
            val songs = (page.songs as? UiState.Success)?.data
            if (page.browseId != YtMusicRepository.LIKED_MUSIC || songs == null) {
                page
            } else {
                page.copy(songs = UiState.Success(songs.filterNot { it.videoId == videoId }))
            }
        }
    }

    /** The heart: liked becomes neutral, anything else becomes liked. */
    fun toggleLike(videoId: String) = setLike(
        videoId,
        if (likeStatusOf(videoId) == LikeStatus.LIKE) LikeStatus.INDIFFERENT else LikeStatus.LIKE,
    )

    /** As [toggleLike], for the thumb-down. */
    fun toggleDislike(videoId: String) = setLike(
        videoId,
        if (likeStatusOf(videoId) == LikeStatus.DISLIKE) {
            LikeStatus.INDIFFERENT
        } else {
            LikeStatus.DISLIKE
        },
    )

    /**
     * Saves the album or playlist [browseId] to the library, or takes it out.
     *
     * Written to the screen first and rolled back if YouTube refuses, for the
     * same reason [setLike] is: it is one tap on a page the user is looking at,
     * and a control that waits on a round trip before it changes reads as a tap
     * that missed.
     *
     * A page with no [DetailPage.library] is one YouTube never offered to save
     * — a local page, an auto-playlist, a generated mix — and the UI has no
     * control on it to have been tapped, so this is a no-op rather than a guess.
     */
    fun toggleLibrary(browseId: String) {
        if (!requireSignIn()) return
        val current = _detailStack.value.firstOrNull { it.browseId == browseId }?.library ?: return
        val target = !current.saved
        setSavedOnPage(browseId, target)
        viewModelScope.launch {
            if (YtMusicRepository.setSaved(current.playlistId, target).isSuccess) {
                // The Library tab's Albums/Playlists shelf is now out of date.
                libraryStale = true
            } else {
                setSavedOnPage(browseId, current.saved)
            }
        }
    }

    /**
     * Restates whether a page is saved. By id rather than by index: the user may
     * have pushed or popped pages while the write was in flight.
     */
    private fun setSavedOnPage(browseId: String, saved: Boolean) {
        _detailStack.value = _detailStack.value.map { page ->
            val library = page.library
            if (page.browseId != browseId || library == null) {
                page
            } else {
                page.copy(library = library.copy(saved = saved))
            }
        }
    }

    /**
     * The open track menu's account state, or null while it is still being
     * fetched. Only one menu can be open at a time, so one slot is enough.
     */
    private val _songMenu = MutableStateFlow<SongMenu?>(null)
    val songMenu: StateFlow<SongMenu?> = _songMenu.asStateFlow()

    private var songMenuJob: Job? = null

    /**
     * Loads the account state behind an opening track menu — the library
     * tokens, and any rating the response happens to state.
     *
     * The rating is only ever taken when it *adds* something: a LIKE or a
     * DISLIKE the library couldn't have told us, such as a disliked track or
     * one liked past the tenth page of Liked Music. An INDIFFERENT is
     * discarded.
     *
     * That asymmetry is not fussiness. This lookup reads a watch queue, and a
     * watch queue routinely renders a liked track with no rating on it at all;
     * believing that silence downgraded songs sitting in Liked Music to
     * "not liked" a beat after their menu opened — the label changing under
     * the user, with no request sent and nothing removed.
     */
    fun loadSongMenu(videoId: String?) {
        songMenuJob?.cancel()
        _songMenu.value = null
        if (videoId == null || !_signedIn.value) return
        songMenuJob = viewModelScope.launch {
            val menu = YtMusicRepository.songMenu(videoId).getOrNull() ?: return@launch
            _songMenu.value = menu
            val stated = menu.likeStatus
            if (stated != null && stated != LikeStatus.INDIFFERENT &&
                videoId !in _likeOverrides.value
            ) {
                _likeOverrides.value += (videoId to stated)
            }
        }
    }

    /** The account's own playlists, for the picker and the library tab. */
    private val _playlists = MutableStateFlow<List<UserPlaylist>>(emptyList())
    val playlists: StateFlow<List<UserPlaylist>> = _playlists.asStateFlow()

    private val _playlistsLoading = MutableStateFlow(false)
    val playlistsLoading: StateFlow<Boolean> = _playlistsLoading.asStateFlow()

    /** Re-fetched rather than cached for the session: playlists are edited here. */
    fun loadPlaylists() {
        if (!_signedIn.value || _playlistsLoading.value) return
        _playlistsLoading.value = true
        viewModelScope.launch {
            YtMusicRepository.userPlaylists().onSuccess { _playlists.value = it }
            _playlistsLoading.value = false
        }
    }

    /**
     * Adds [song] to a playlist.
     *
     * Not optimistic, unlike a rating: there is nothing on screen to update
     * ahead of the answer, and a "Added to X" that turns out to be untrue is
     * worse than one that arrives a moment late.
     */
    fun addToPlaylist(playlist: UserPlaylist, song: Song) {
        if (!requireSignIn()) return
        viewModelScope.launch {
            YtMusicRepository.addToPlaylist(playlist.playlistId, listOf(song.videoId)).fold(
                onSuccess = { libraryStale = true },
                onFailure = {},
            )
        }
    }

    /**
     * Creates a playlist, seeded with [song] when the flow started from a
     * track's menu — one request, so it can't half-succeed into an empty
     * playlist the user has to add to again.
     */
    fun createPlaylist(title: String, privacy: PlaylistPrivacy, song: Song? = null) {
        if (!requireSignIn()) return
        val name = title.trim().ifBlank { "New playlist" }
        viewModelScope.launch {
            YtMusicRepository.createPlaylist(
                title = name,
                privacy = privacy,
                videoIds = listOfNotNull(song?.videoId),
            ).fold(
                onSuccess = {
                    libraryStale = true
                    loadPlaylists()
                    refresh(Feed.LIBRARY)
                },
                onFailure = {},
            )
        }
    }

    /**
     * Drops [song] from the playlist page it is being read on, and takes the
     * row out from under the reader rather than waiting for a re-fetch.
     */
    fun removeFromPlaylist(browseId: String, song: Song) {
        val setVideoId = song.setVideoId ?: return
        if (!requireSignIn()) return
        val playlistId = browseId.removePrefix("VL")
        viewModelScope.launch {
            YtMusicRepository.removeFromPlaylist(
                playlistId,
                listOf(setVideoId to song.videoId),
            ).fold(
                onSuccess = {
                    libraryStale = true
                    _detailStack.value = _detailStack.value.map { page ->
                        val songs = (page.songs as? UiState.Success)?.data
                        if (page.browseId != browseId || songs == null) {
                            page
                        } else {
                            page.copy(
                                songs = UiState.Success(
                                    songs.filterNot { it.setVideoId == setVideoId },
                                ),
                            )
                        }
                    }
                },
                onFailure = {},
            )
        }
    }

    /**
     * Adds one of [DetailPage.suggestedSongs] to the playlist it was
     * suggested for, and drops it from that section — the playlist's own
     * track list only shows it correctly (with a working "remove") once the
     * page is reopened, so there is nothing on screen for it to move to yet.
     */
    fun addSuggestedSong(browseId: String, song: Song) {
        if (!requireSignIn()) return
        val playlistId = browseId.removePrefix("VL")
        viewModelScope.launch {
            YtMusicRepository.addToPlaylist(playlistId, listOf(song.videoId)).fold(
                onSuccess = {
                    libraryStale = true
                    _detailStack.value = _detailStack.value.map { page ->
                        if (page.browseId != browseId) {
                            page
                        } else {
                            page.copy(
                                suggestedSongs = page.suggestedSongs
                                    .filterNot { it.videoId == song.videoId },
                            )
                        }
                    }
                },
                onFailure = {},
            )
        }
    }

    fun renamePlaylist(playlist: UserPlaylist, title: String) {
        if (!requireSignIn()) return
        val name = title.trim()
        if (name.isBlank() || name == playlist.title) return
        viewModelScope.launch {
            YtMusicRepository.renamePlaylist(playlist.playlistId, name).fold(
                onSuccess = {
                    _playlists.value = _playlists.value.map {
                        if (it.playlistId == playlist.playlistId) it.copy(title = name) else it
                    }
                    libraryStale = true
                    refresh(Feed.LIBRARY)
                },
                onFailure = {},
            )
        }
    }

    fun deletePlaylist(playlist: UserPlaylist) {
        if (!requireSignIn()) return
        viewModelScope.launch {
            YtMusicRepository.deletePlaylist(playlist.playlistId).fold(
                onSuccess = {
                    _playlists.value = _playlists.value
                        .filterNot { it.playlistId == playlist.playlistId }
                    // Its page may be the one open; a deleted playlist has
                    // nothing left to show.
                    _detailStack.value = _detailStack.value
                        .filterNot { it.browseId == playlist.browseId }
                    AppSettings.unpinPlaylist(playlist.browseId)
                    AppSettings.unpinPlaylist(playlist.playlistId)
                    libraryStale = true
                    refresh(Feed.LIBRARY)
                },
                onFailure = {},
            )
        }
    }

    /** Whether [browseId] is a playlist this account can be asked to edit. */
    fun editablePlaylist(browseId: String?): UserPlaylist? {
        if (browseId == null) return null
        return _playlists.value.firstOrNull { it.browseId == browseId }
    }

    /**
     * Guards every account write. All of them are signed-in-only, and the UI
     * hides them for guests — this is the backstop for a session that expired
     * between the menu opening and the tap.
     */
    private fun requireSignIn(): Boolean = _signedIn.value

    /**
     * Whether the library needs re-fetching. Set by every write above and
     * acted on when the tab is next opened, for the same reason [homeStale]
     * exists: rearranging a page under whoever is reading it is worse than
     * showing it a moment out of date.
     */
    private var libraryStale = false

    /** Call when the library tab becomes visible. */
    fun onLibraryShown() {
        loadPlaylists()
        if (!libraryStale) return
        libraryStale = false
        if (_library.value is UiState.Success) refresh(Feed.LIBRARY)
    }

    init {
        startSearchPipeline()
        startSuggestPipeline()
        loadHome()
        loadExplore()
        if (_signedIn.value) {
            loadLibrary()
            loadAccount()
            loadPlaylists()
        }
        viewModelScope.launch {
            // drop(1): the current value is just the count so far, not a play.
            PlaybackTracker.registeredPlays.drop(1).collect { homeStale = true }
        }
    }

    /**
     * Whether a play has been registered since the home feed was last fetched.
     *
     * The feed leads with listening history, so it's out of date the moment a
     * track starts — but re-fetching there would rearrange the page under
     * whoever is reading it, and the tab is usually in the background anyway.
     * It's re-fetched when the tab is next opened instead.
     */
    private var homeStale = false

    /** Call when the home tab becomes visible. */
    fun onHomeShown() {
        if (!homeStale) return
        homeStale = false
        // A first load already in flight will pick the new play up by itself.
        if (_home.value is UiState.Success) refresh(Feed.HOME)
    }

    private fun loadAccount() {
        viewModelScope.launch {
            _account.value = YtMusicRepository.account().getOrNull()
        }
    }

    /**
     * A feed that can be pulled down to refresh. Tracked per feed rather than
     * as one flag: a pull on Library while Home is still refreshing in the
     * background shouldn't leave the wrong tab showing a loader.
     */
    enum class Feed { HOME, EXPLORE, LIBRARY }

    private val _refreshing = MutableStateFlow(emptySet<Feed>())
    val refreshing: StateFlow<Set<Feed>> = _refreshing.asStateFlow()

    /**
     * Re-fetches [feed] in place. Unlike the `load*` entry points this leaves
     * the current content on screen rather than dropping back to the loading
     * state — a refresh that swapped the page for a spinner would be a worse
     * experience than the stale content it replaces.
     */
    fun refresh(feed: Feed) {
        if (feed in _refreshing.value) return
        if (feed == Feed.LIBRARY && !_signedIn.value) return
        _refreshing.value = _refreshing.value + feed
        viewModelScope.launch {
            try {
                when (feed) {
                    Feed.HOME -> fetchHome()
                    Feed.EXPLORE -> fetchExplore()
                    Feed.LIBRARY -> fetchLibrary()
                }
            } finally {
                _refreshing.value = _refreshing.value - feed
            }
        }
    }

    fun loadExplore() {
        _explore.value = UiState.Loading
        viewModelScope.launch { fetchExplore() }
    }

    private suspend fun fetchExplore() {
        _explore.value = YtMusicRepository.explore().fold(
            onSuccess = { shelves ->
                if (shelves.isEmpty()) UiState.Error("Nothing to explore right now")
                else UiState.Success(shelves)
            },
            onFailure = { UiState.Error(it.friendly()) },
        )
    }

    /** Tapping a tab should leave any pushed page behind. */
    fun clearDetail() {
        localDetailJobs.values.forEach { it.cancel() }
        localDetailJobs.clear()
        if (_detailStack.value.isNotEmpty()) _detailStack.value = emptyList()
    }

    fun loadHome() {
        _home.value = UiState.Loading
        viewModelScope.launch { fetchHome() }
    }

    private suspend fun fetchHome() {
        homeContinuation = null
        homeSeenTitles.clear()
        val result = YtMusicRepository.home()
        result.fold(
            onSuccess = { feed ->
                homeContinuation = feed.continuation
                val shelves = feed.shelves.filter { homeSeenTitles.add(it.title.lowercase()) }
                if (shelves.isEmpty()) {
                    if (_home.value !is UiState.Success) {
                        _home.value = UiState.Error("No results from YouTube Music")
                    }
                } else {
                    _home.value = UiState.Success(shelves)
                }
            },
            onFailure = {
                if (_home.value !is UiState.Success) {
                    _home.value = UiState.Error(it.friendly())
                }
            },
        )
    }

    /**
     * Called as the Home list nears its end. A no-op while a page is already
     * in flight, once the feed is exhausted, or before the first page has
     * loaded — [homeContinuation] covers all three by construction.
     */
    fun loadMoreHome() {
        val token = homeContinuation ?: return
        if (_homeLoadingMore.value) return
        _homeLoadingMore.value = true
        viewModelScope.launch {
            YtMusicRepository.moreHome(token).onSuccess { feed ->
                val added = feed.shelves.filter { homeSeenTitles.add(it.title.lowercase()) }
                // A page with nothing new signals the feed has looped back on
                // itself rather than run dry with a token still attached —
                // treat it the same as exhausted so scrolling can't spin here.
                homeContinuation = feed.continuation.takeIf { added.isNotEmpty() }
                if (added.isNotEmpty()) {
                    val existing = (_home.value as? UiState.Success)?.data ?: emptyList()
                    _home.value = UiState.Success(existing + added)
                }
            }
            _homeLoadingMore.value = false
        }
    }

    fun loadLibrary() {
        if (!_signedIn.value) return
        _library.value = UiState.Loading
        viewModelScope.launch { fetchLibrary() }
    }

    private suspend fun fetchLibrary() {
        _library.value = YtMusicRepository.library().fold(
            onSuccess = { page ->
                if (page.isEmpty) UiState.Error("Nothing in your library yet")
                else UiState.Success(page)
            },
            onFailure = { UiState.Error(it.friendly()) },
        )
    }

    /** Recent searches, kept on device. */
    val searchHistory: StateFlow<List<String>> = SearchHistory.recent

    fun onQueryChange(value: String) {
        val previous = _query.value
        _query.value = value
        if (value.isBlank()) {
            // Emptying the field is how the recent searches are got back to,
            // so it takes down the suggestions and the results together.
            // Nothing in flight can still be waiting to overwrite the latter:
            // the id it would be checked against has already moved past it.
            newestRequestId.incrementAndGet()
            _results.value = null
            _suggestions.value = emptyList()
            return
        }
        // The previous keystroke's completions are left up beneath the new
        // lead row while the fresh ones are fetched — the same reasoning as
        // [prefixMatch]: they were right a letter ago, and a list that
        // collapses to one row on every letter is what makes a typeahead feel
        // broken. Text that isn't a continuation of what they were for (the
        // whole field replaced at once, say) drops them instead of showing
        // completions of a query that's gone.
        val stale = if (value.startsWith(previous, true) || previous.startsWith(value, true)) {
            _suggestions.value.drop(1)
        } else {
            emptyList()
        }
        _suggestions.value = listOf(value) + stale.filterNot { it.equals(value, true) }
        suggestRequests.tryEmit(value)
    }

    /**
     * Commits the current query to the history. Called when the user acts on
     * what they found — submitting from the keyboard, or opening a result —
     * rather than on every keystroke, which would fill the list with the
     * prefixes typed on the way to the real query.
     */
    fun recordSearch() = SearchHistory.record(_query.value)

    /**
     * The search button — the keyboard's search action, or the magnifier in
     * the field. The only thing that runs a search for text the user typed:
     * keystrokes themselves ask for suggestions and nothing more, so a query
     * is fetched once, when they say it's finished, instead of once per
     * prefix on the way to it.
     */
    fun submitSearch() {
        recordSearch()
        _suggestions.value = emptyList()
        runSearch()
    }

    /**
     * Runs a term the user picked out of a list rather than typed — a recent
     * search, or one of [suggestions] — and floats it to the top of the
     * history. Picking is as deliberate as submitting, so it searches on the
     * spot.
     */
    fun searchFor(term: String) {
        _query.value = term
        _suggestions.value = emptyList()
        SearchHistory.record(term)
        runSearch()
    }

    fun removeSearch(term: String) = SearchHistory.remove(term)

    fun clearSearchHistory() = SearchHistory.clear()

    fun onFilterChange(value: SearchFilter) {
        if (_filter.value == value) return
        _filter.value = value
        runSearch()
    }

    /**
     * A search asked for, as a request the pipeline below decides what to do
     * with.
     *
     * [requestId] is what makes a late answer harmless: a response is only
     * written to the screen if its id is still the newest one asked for.
     */
    private data class SearchRequest(
        val query: String,
        val filter: SearchFilter,
        val requestId: Long,
    )

    private fun cacheKey(query: String, filter: SearchFilter) = "${filter.name}:$query"

    /**
     * The results of the longest earlier query this one starts with — near
     * enough to leave up while the narrower search runs.
     */
    private fun prefixMatch(query: String, filter: SearchFilter): List<SearchResult>? {
        val prefix = "${filter.name}:"
        return searchCache.snapshot()
            .filterKeys { it.startsWith(prefix) && query.startsWith(it.removePrefix(prefix), true) }
            .maxByOrNull { it.key.length }
            ?.value
    }

    private fun runSearch() {
        val query = _query.value
        if (query.isBlank()) {
            // Nothing in flight can still be waiting to overwrite this: the
            // id it would be checked against has already moved past it.
            newestRequestId.incrementAndGet()
            _results.value = null
            return
        }
        val id = newestRequestId.incrementAndGet()
        searchRequests.tryEmit(SearchRequest(query, _filter.value, id))
    }

    /**
     * The search pipeline, started once and left running for the lifetime of
     * the view model.
     *
     * The point of it being one long-lived collector is that a new search no
     * longer cancels the request before it out of a fresh coroutine.
     * Cancelling a call mid-flight tears down its socket, and on a pooled HTTP
     * client that is felt by whatever picks that connection up next — which is
     * how one search could end in "Software caused connection abort" for a
     * request that was never itself in any trouble.
     *
     * There is no debounce here any more, and nothing to absorb: a search is
     * only ever asked for by a deliberate act — the search button, a
     * suggestion or history row, a filter tab — so the request that arrives is
     * already the one the user meant, and making them wait out a timer for it
     * would be a delay with nothing behind it. Typing asks
     * [startSuggestPipeline] for completions instead and leaves the results
     * alone.
     */
    private fun startSearchPipeline() = viewModelScope.launch {
        searchRequests
            .collectLatest { request ->
                val key = cacheKey(request.query, request.filter)
                // Something to look at immediately: the exact answer if this
                // query has been run before, otherwise the closest earlier
                // one. Only fall back to a spinner with neither.
                val exact = searchCache.get(key)
                val cached = exact ?: prefixMatch(request.query, request.filter)
                _results.value = cached?.let { UiState.Success(it) } ?: UiState.Loading
                if (exact != null) return@collectLatest

                // Search is YouTube's alone. A module is a *substitution*
                // layer, not a catalogue to browse: it never has cover art,
                // radio, related tracks or an album page, so its rows arrived
                // in the results list looking like YouTube's and then behaved
                // nothing like them. Every track found here takes the ordinary
                // YouTube path and is handed to the module at playback time —
                // see [SourceResolver.substituteForYouTube] — which upgrades
                // the ones it holds without any of them having to be a
                // separate row to pick between.
                val result = YtMusicRepository.search(request.query, request.filter)
                // A search that has been superseded shouldn't land on screen,
                // whether it succeeded or failed.
                if (request.requestId != newestRequestId.get()) return@collectLatest
                _results.value = result.fold(
                    onSuccess = { rows -> published(rows, key) },
                    onFailure = { failure -> UiState.Error(failure.friendly()) },
                )
            }
    }

    /**
     * The typeahead pipeline, alongside [startSearchPipeline] and for the same
     * structural reason — one long-lived collector rather than a coroutine per
     * keystroke, so a lookup the user has typed past doesn't take a pooled
     * socket down with it.
     *
     * This one *does* debounce, and that isn't the timer that was taken off the
     * search. It's two orders of magnitude shorter, and it's paid for by the
     * request behind it being a few hundred bytes rather than a full page of
     * results — a burst of keystrokes shouldn't each cost a round trip, but the
     * gap has to be short enough that the list is up before the next letter is
     * typed. Nothing is waiting on it either way: the row the user typed is
     * already on screen from the keystroke itself.
     *
     * A failure is left on the floor. There is no worthwhile way to report
     * "couldn't suggest anything" in a list of suggestions, and the typed text
     * is standing there as a working first row regardless.
     */
    @OptIn(FlowPreview::class)
    private fun startSuggestPipeline() = viewModelScope.launch {
        // Whether a list for [input] is still wanted. False once the field has
        // moved on: typed further, or searched — which empties [_suggestions],
        // and a late answer writing to it would reopen the suggestions over
        // the results the user is by then reading.
        fun stillWanted(input: String) =
            _query.value == input && _suggestions.value.isNotEmpty()

        suggestRequests
            .debounce(SUGGEST_DEBOUNCE_MS)
            .collectLatest { input ->
                if (!stillWanted(input)) return@collectLatest
                val fetched = YtMusicRepository.searchSuggestions(input).getOrNull()
                    ?: return@collectLatest
                // Asked again on the way back; the field is live throughout.
                if (!stillWanted(input)) return@collectLatest
                _suggestions.value = listOf(input) +
                    fetched.filterNot { it.equals(input, ignoreCase = true) }
            }
    }

    /** Caches and publishes one result list. */
    private fun published(rows: List<SearchResult>, key: String): UiState<List<SearchResult>> {
        if (rows.isEmpty()) return UiState.Error("No results")
        searchCache.put(key, rows)
        prefetchTopResult(rows)
        return UiState.Success(rows)
    }

    /**
     * The enabled non-YouTube sources, asked at the same time and returned
     * split at YouTube's own place in the order.
     *
     * The split is what makes the Sources screen's ordering visible where it
     * matters most. A library server ranked above YouTube puts its own copies
     * at the top of the results — which is the whole point of ranking it there —
     * and one ranked below appears under them instead.
     *
     * Only the Songs filter fans out: albums, artists and playlists are
     * browse-shaped, and [MusicSource] deliberately answers for tracks only.
     */
    private suspend fun sourceResults(
        query: String,
        filter: SearchFilter,
    ): Pair<List<SearchResult>, List<SearchResult>> = coroutineScope {
        if (filter != SearchFilter.SONGS) return@coroutineScope emptyList<SearchResult>() to emptyList()
        val active = SourceRegistry.active()
        val youtubeRank = active.indexOfFirst { it.kind == SourceKind.YOUTUBE }
            .let { if (it < 0) active.size else it }

        val answers = active
            .filter { it.kind != SourceKind.YOUTUBE }
            .map { source ->
                source to async {
                    // Per-source, so one slow or unreachable server delays the
                    // results by at most this much rather than for as long as
                    // its socket takes to give up.
                    runCatching {
                        withTimeout(SOURCE_SEARCH_TIMEOUT_MS) { source.search(query, SOURCE_SEARCH_LIMIT) }
                    }.getOrDefault(emptyList())
                }
            }

        val above = mutableListOf<SearchResult>()
        val below = mutableListOf<SearchResult>()
        answers.forEach { (source, job) ->
            val rows = job.await().map { SearchResult.Track(it) }
            val rank = active.indexOfFirst { it.configId == source.configId }
            if (rank in 0 until youtubeRank) above += rows else below += rows
        }
        above to below
    }

    /**
     * Warms the stream URL for the top song result the instant results land,
     * not when it's tapped. [AudioCache] gives a head start to whatever's
     * already queued; a fresh search has nothing queued yet, and the top
     * result is overwhelmingly what gets tapped — see [play][MainActivity.play].
     * [resolveAudio][YtMusicRepository.resolveAudio] first, same as the tap
     * path itself, so a video-tagged result warms the catalogue audio's id
     * rather than one nothing will ever ask for.
     */
    private fun prefetchTopResult(rows: List<SearchResult>) {
        val song = rows.filterIsInstance<SearchResult.Track>().firstOrNull()?.song ?: return
        viewModelScope.launch {
            runCatching {
                StreamResolver.resolve(YtMusicRepository.resolveAudio(song).videoId)
            }
        }
    }

    private companion object {
        /**
         * How long a keystroke waits before the typeahead is asked about it.
         *
         * Not the search's timer — searches aren't on a timer any more. This
         * one only stops a fast typist spending a round trip per letter, so it
         * wants to be as short as it can be while still collapsing a burst:
         * long enough that "cold" isn't four lookups, short enough that the
         * list is up by the time the thumb has left the key.
         */
        const val SUGGEST_DEBOUNCE_MS = 180L

        const val SEARCH_CACHE_ENTRIES = 100

        /**
         * How long any one source gets to answer a search.
         *
         * Short on purpose: these run alongside the YouTube search, and their
         * only job is to be *there* when it lands. A home server reached over
         * a VPN that takes eight seconds has effectively not answered, and
         * holding the whole result list for it would make search feel worse
         * for the sake of results the user can still get by searching again.
         */
        const val SOURCE_SEARCH_TIMEOUT_MS = 4000L

        /** Enough to be worth scrolling, short enough not to bury YouTube's own rows. */
        const val SOURCE_SEARCH_LIMIT = 12
    }

    private val localDetailJobs = mutableMapOf<String, Job>()

    fun openDetail(
        browseId: String,
        title: String,
        subtitle: String = "",
        thumbnailUrl: String? = null,
        type: BrowseType = BrowseType.OTHER,
    ) {
        val resolved = browseTypeOf(browseId, type)
        val initialFacts = if (resolved == BrowseType.ARTIST) {
            val cached = com.soundhive.data.artist.ArtistFactsRepository.getCached(title)
            if (cached != null) UiState.Success(cached) else UiState.Loading
        } else null

        _detailStack.value += DetailPage(
            browseId = browseId,
            title = title,
            subtitle = subtitle,
            thumbnailUrl = thumbnailUrl,
            songs = UiState.Loading,
            type = resolved,
            artistFacts = initialFacts,
        )

        if (browseId == "local:downloads") {
            localDetailJobs[browseId]?.cancel()
            localDetailJobs[browseId] = viewModelScope.launch {
                val context = getApplication<Application>()
                LocalMediaRepository.observeDownloadedSongs(context).collect { songs ->
                    val stack = _detailStack.value
                    if (stack.none { it.browseId == browseId }) {
                        cancel()
                        return@collect
                    }
                    val state = if (songs.isEmpty()) UiState.Error("No downloaded tracks found")
                    else UiState.Success(songs)
                    _detailStack.value = _detailStack.value.map { page ->
                        if (page.browseId == browseId) {
                            page.copy(songs = state)
                        } else page
                    }
                }
            }
            return
        }

        if (browseId == "local:all") {
            localDetailJobs[browseId]?.cancel()
            localDetailJobs[browseId] = viewModelScope.launch {
                val context = getApplication<Application>()
                if (!LocalMediaRepository.hasStoragePermission(context)) {
                    _detailStack.value = _detailStack.value.map { page ->
                        if (page.browseId == browseId) {
                            page.copy(songs = UiState.Error("Storage permission required to view local audio files"))
                        } else page
                    }
                } else {
                    LocalMediaRepository.observeLocalMusic(context).collect { songs ->
                        val stack = _detailStack.value
                        if (stack.none { it.browseId == browseId }) {
                            cancel()
                            return@collect
                        }
                        val state = if (songs.isEmpty()) UiState.Error("No audio files found on device")
                        else UiState.Success(songs)
                        _detailStack.value = _detailStack.value.map { page ->
                            if (page.browseId == browseId) {
                                page.copy(songs = state)
                            } else page
                        }
                    }
                }
            }
            return
        }

        if (browseId.startsWith(Downloads.PLAYLIST_PREFIX)) {
            val collectionId = Downloads.recordIdOf(browseId) ?: ""
            localDetailJobs[browseId]?.cancel()
            localDetailJobs[browseId] = viewModelScope.launch {
                val context = getApplication<Application>()
                LocalMediaRepository.observeDownloadedSongs(context).collect { downloadedSongs ->
                    val stack = _detailStack.value
                    if (stack.none { it.browseId == browseId }) {
                        cancel()
                        return@collect
                    }
                    val collections = Downloads.collectionsAmong(downloadedSongs)
                    val matching = collections.firstOrNull { it.id == collectionId }
                    val songs = matching?.songs.orEmpty()
                    val state = if (songs.isEmpty()) UiState.Error("No tracks in this playlist")
                    else UiState.Success(songs)
                    _detailStack.value = _detailStack.value.map { page ->
                        if (page.browseId == browseId) {
                            page.copy(
                                songs = state,
                                title = matching?.title ?: page.title,
                                subtitle = matching?.subtitle ?: page.subtitle,
                                thumbnailUrl = matching?.thumbnailUrl ?: page.thumbnailUrl,
                            )
                        } else page
                    }
                }
            }
            return
        }

        loadRemoteDetail(browseId, title, thumbnailUrl, resolved)
    }

    fun retryDetail(browseId: String) {
        val page = _detailStack.value.firstOrNull { it.browseId == browseId } ?: return
        _detailStack.value = _detailStack.value.map {
            if (it.browseId == browseId) it.copy(songs = UiState.Loading) else it
        }
        loadRemoteDetail(browseId, page.title, page.thumbnailUrl, page.type)
    }

    private fun loadRemoteDetail(
        browseId: String,
        title: String,
        thumbnailUrl: String?,
        resolved: BrowseType,
    ) {
        viewModelScope.launch {
            var sections = emptyList<HomeShelf>()
            var artwork: String? = null
            var name: String? = null
            var more: String? = null
            var suggested: List<Song> = emptyList()
            var library: LibraryState? = null
            var artistBio: String? = null
            var artistSubs: String? = null
            val state = when {
                resolved == BrowseType.ARTIST -> {
                    YtMusicRepository.artistPage(browseId).fold(
                        onSuccess = { page ->
                            sections = page.sections
                            artwork = page.thumbnailUrl
                            name = page.name
                            artistBio = page.description
                            artistSubs = page.subscribers
                            if (page.songs.isEmpty()) {
                                UiState.Error("No tracks here")
                            } else {
                                UiState.Success(page.songs.withArtwork(thumbnailUrl))
                            }
                        },
                        onFailure = { UiState.Error(it.friendly()) },
                    )
                }
                else -> {
                    YtMusicRepository.browseSongs(browseId).fold(
                        onSuccess = { page ->
                            if (page.songs.isEmpty()) {
                                UiState.Error("No tracks here")
                            } else {
                                more = page.continuation
                                suggested = page.suggested.withArtwork(thumbnailUrl)
                                library = page.library
                                UiState.Success(page.songs.withArtwork(thumbnailUrl))
                            }
                        },
                        onFailure = { UiState.Error(it.friendly()) },
                    )
                }
            }
            _detailStack.value = _detailStack.value.map {
                if (it.browseId == browseId) {
                    it.copy(
                        songs = state,
                        sections = sections.takeIf { s -> s.isNotEmpty() } ?: it.sections,
                        thumbnailUrl = artwork ?: it.thumbnailUrl,
                        title = name ?: it.title,
                        suggestedSongs = suggested.takeIf { s -> s.isNotEmpty() } ?: it.suggestedSongs,
                        library = library ?: it.library,
                    )
                } else {
                    it
                }
            }
            more?.let { fillIn(browseId, it, thumbnailUrl) }

            if (resolved == BrowseType.ARTIST) {
                val effectiveArtistName = name ?: title
                viewModelScope.launch {
                    val facts = com.soundhive.data.artist.ArtistFactsRepository.getArtistFacts(
                        artistName = effectiveArtistName,
                        ytDescription = artistBio,
                        ytSubscribers = artistSubs,
                    )
                    _detailStack.value = _detailStack.value.map { page ->
                        if (page.browseId == browseId) {
                            page.copy(artistFacts = UiState.Success(facts))
                        } else page
                    }
                }
            }
        }
    }

    fun reloadLocalDetail(browseId: String) {
        LocalMediaRepository.rescan()
    }

    /**
     * Follows a detail page's continuations in the background, appending each
     * page to what is already being read.
     *
     * A playlist of a few hundred tracks is several round trips, and taking
     * them before showing anything meant a spinner for all of them. Growing
     * the list underneath the reader is also what makes it safe to keep
     * following continuations [YtMusicRepository.MAX_PAGES] deep — nobody is
     * waiting on the last one.
     *
     * Stops the moment the page leaves the stack: there is no one to append
     * for.
     */
    private fun fillIn(browseId: String, token: String, artworkFallback: String?) {
        viewModelScope.launch {
            var next: String? = token
            var page = 1
            while (next != null && page++ < YtMusicRepository.MAX_PAGES) {
                val fetched = YtMusicRepository.moreSongs(next).getOrNull() ?: return@launch
                val stack = _detailStack.value
                val index = stack.indexOfFirst { it.browseId == browseId }
                if (index < 0) return@launch
                val current = stack[index]
                val existing = (current.songs as? UiState.Success)?.data ?: return@launch
                val known = existing.mapTo(HashSet()) { it.videoId }
                val added = fetched.songs
                    .filter { known.add(it.videoId) }
                    .withArtwork(artworkFallback)
                // Suggestions can arrive on a later page than the real
                // tracks, once the playlist's own continuation runs dry —
                // see parsePlaylistShelf — so they're tracked separately
                // rather than folded into [known].
                val knownSuggested = current.suggestedSongs.mapTo(HashSet()) { it.videoId }
                val addedSuggested = fetched.suggested
                    .filter { it.videoId !in known && knownSuggested.add(it.videoId) }
                    .withArtwork(artworkFallback)
                // A page with nothing new on it means the feed has looped back
                // rather than run dry with a token still attached.
                if (added.isEmpty() && addedSuggested.isEmpty()) return@launch
                _detailStack.value = stack.toMutableList().also {
                    it[index] = current.copy(
                        songs = UiState.Success(existing + added),
                        suggestedSongs = current.suggestedSongs + addedSuggested,
                    )
                }
                next = fetched.continuation
            }
        }
    }

    /**
     * An album's track listing doesn't repeat the cover on every row — the
     * page carries it once — so rows arrive with no artwork and stay blank
     * through to the queue and the notification. Fall back to the page's.
     */
    private fun List<Song>.withArtwork(fallback: String?): List<Song> {
        if (fallback == null) return this
        return map { if (it.thumbnailUrl == null) it.copy(thumbnailUrl = fallback) else it }
    }

    fun browseTypeOf(browseId: String, fallback: BrowseType = BrowseType.OTHER): BrowseType = when {
        browseId.startsWith(Downloads.PLAYLIST_PREFIX) -> BrowseType.PLAYLIST
        browseId.startsWith("UC") -> BrowseType.ARTIST
        browseId.startsWith("MPREb") -> BrowseType.ALBUM
        browseId.startsWith("VL") || browseId.startsWith("PL") -> BrowseType.PLAYLIST
        else -> fallback
    }

    private suspend fun downloadedPlaylist(browseId: String): List<Song> {
        val id = Downloads.recordIdOf(browseId) ?: return emptyList()
        val folder = LocalMediaRepository.getDownloadedSongs(getApplication())
        return Downloads.collectionsAmong(folder).firstOrNull { it.id == id }?.songs.orEmpty()
    }

    fun collectSongs(
        browseId: String,
        artworkFallback: String? = null,
        onResult: (Result<List<Song>>) -> Unit,
    ) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val result = when {
                Downloads.recordIdOf(browseId) != null -> runCatching {
                    downloadedPlaylist(browseId).ifEmpty { error("Nothing from this playlist is on this device any more") }
                }
                browseId == "local:downloads" -> runCatching {
                    LocalMediaRepository.getDownloadedSongs(context)
                        .ifEmpty { error("No downloaded tracks found") }
                }
                browseId == "local:all" -> runCatching {
                    if (!LocalMediaRepository.hasStoragePermission(context)) {
                        error("Storage permission required to read local audio files")
                    }
                    LocalMediaRepository.getLocalMusic(context)
                        .ifEmpty { error("No audio files found on device") }
                }
                else -> YtMusicRepository.allSongs(browseId)
            }
            onResult(result.map { it.withArtwork(artworkFallback) })
        }
    }

    /** Pops one page; returns false when there was nothing to pop. */
    fun closeDetail(): Boolean {
        val stack = _detailStack.value
        if (stack.isEmpty()) return false
        val popped = stack.last()
        localDetailJobs.remove(popped.browseId)?.cancel()
        _detailStack.value = stack.dropLast(1)
        return true
    }

    fun onSignedIn(cookie: String) {
        authStore.cookie = cookie
        Innertube.cookie = cookie
        _signedIn.value = true
        loadHome()
        loadLibrary()
        loadAccount()
        loadPlaylists()
    }

    fun signOut() {
        authStore.signOut()
        Innertube.cookie = null
        _signedIn.value = false
        _account.value = null
        _library.value = UiState.Loading
        // Ratings and playlists belong to the account that just left; keeping
        // them would show the next signed-in user someone else's hearts.
        _likeOverrides.value = emptyMap()
        _playlists.value = emptyList()
        _songMenu.value = null
        loadHome()
    }

    private fun Throwable.friendly(): String =
        com.soundhive.data.network.NetworkErrorMapper.toUserMessage(this)
}
